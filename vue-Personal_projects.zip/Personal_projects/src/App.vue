<template>
	<div id="app" :appkey="appkey" 
		v-loading="loading"
        element-loading-text="拼命加载中"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(255, 255, 255, 0.8)"
    >
		<keep-alive>
			<router-view v-if="$route.meta.keepAlive"></router-view>
		</keep-alive>
		<router-view v-if="!$route.meta.keepAlive"></router-view>
	</div>
</template>

<script>
import { mapState } from "vuex"
export default {
	name: 'app',
	data() {
		return {
			appkey: 1
		}
	},
	computed: {
		...mapState(["loading"])
	},
	watch: {
		'$route': function () { // 防止页面出现 路由改变  页面卡死的状态
			this.appkey = new Date().getTime()
		} 
	}
}
</script>

<style>
	body { text-align: center; }

	body,ul,ol,h1,h2,h3,h4,h5,h6,p,input,select,textarea,dl,dd{margin: 0;padding: 0;}
	ul,ol{list-style: none;}
	i,em{ font-style:normal}
	input,select,textarea{background-color: transparent; border: none; outline: none;}
	textarea{resize: none;}/*右下角的小尾巴*/
	img{border: none; vertical-align: top;}
	a{text-decoration: none;}
	input[type=date],input[type=text] {
		cursor: pointer;
		-webkit-appearance: none;
	}

	.clearfix:after,.clearfix:before{content: "";display: table;}
	.clearfix:after{clear: both;}
	.clearfix{*zoom:1;}

	.fl{
		float: left;
	}
	.fr{
		float: right;
	}
	.dino{
		display: none;
	}
	.op0{
		opacity: 0;
	}

	h1 {
		margin: 50px auto 100px;
	}
</style>
