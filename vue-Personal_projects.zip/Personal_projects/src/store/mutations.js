export default {
    set_username(state, username) {
        state.username = username
    },
    set_role(state, role) {
        state.role = role
    },
    set_newrouter(state, newrouter) {
        state.newrouter = newrouter
    },
    set_routearr(state, route) {
        state.routearr = route
    },
    push_routearr(state, route) {
        state.routearr.push(route)
    },
    set_color(state, color) {
        state.color = color
    },
    set_loading(state, loading) {
        state.loading = loading
    }
}