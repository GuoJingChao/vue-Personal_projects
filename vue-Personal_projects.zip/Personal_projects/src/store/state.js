export default {
    username: localStorage.getItem("username"),
    role: localStorage.getItem("role"),
    newrouter: [],
    routearr: [],
    color: localStorage.getItem("color"),
    loading: false
}