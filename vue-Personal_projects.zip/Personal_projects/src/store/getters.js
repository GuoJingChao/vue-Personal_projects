export default {
    username: (state) => {
        return state.username
    },
    role: (state) => {
        return state.role
    },
    newrouter: (state) => {
        return state.newrouter
    },
    routearr: (state) => {
        return state.routearr
    }
}