import Vue from "vue"
import VueRouter from "vue-router"

Vue.use(VueRouter)

export default new VueRouter({
    // mode: "history",
    base: "/",
    routes: [
        
        {
            path: "/login",
            name: "Login",
            component: () => import('@/pages/login.vue')
        },
        {
            path: "/all/:name",
            name: "All",
            component: () => import('@/pages/all.vue')
        },
        {
            path: "/all2",
            name: "All2",
            component: () => import('@/pages/all2.vue')
        },
        {
            path: "/all3",
            name: "All3",
            component: () => import('@/pages/all3.vue')
        }
        
    ]
})

export const powerRouter = [
    {
        path: "/",
        name: "Index",
        redirect: "/home",
        component: () => import('@/pages/index.vue'),
        meta: {label: "首页"},
        children: [
            { 
                path: "home", 
                name: "Home", 
                component: () => import('@/pages/home.vue'),
                meta: {label: "首页"}
            },
            { 
                path: "othera", 
                name: "OtherA", 
                component: () => import('@/pages/othera.vue'), 
                meta: {role: ["B","C"],label: "页面2",keepAlive: true} 
            },
            { 
                path: "otherb", 
                name: "OtherB", 
                component: () => import('@/pages/otherb.vue'), 
                children: [
                    { 
                        path: "bbb", 
                        name: "BBB", 
                        component: () => import('@/pages/otherb/bbb.vue'), 
                        meta: {role: ["B"],label: "页面3-1"}
                    },
                    { 
                        path: "bbd", 
                        name: "BBB2", 
                        component: () => import('@/pages/otherb/bbb2.vue'), 
                        meta: {role: ["B"],label: "页面3-2"},
                        children: [
                            {
                                path: "bbd2", 
                                name: "BBB2-3", 
                                component: () => import('@/pages/otherb/bbb2-3.vue'), 
                                meta: {role: ["B"],label: "页面3-2-1"},
                            }
                        ]
                    }
                ], 
                meta: {role: ["B","D"],label: "页面3"} },
            { 
                path: "otherc", 
                name: "OtherC", 
                component: () => import('@/pages/otherc.vue'), 
                meta: {role: ["C","D"],label: "页面4"} 
            },
            { 
                path: "otherd", 
                name: "OtherD", 
                component: () => import('@/pages/otherd.vue'), 
                meta: {role: ["D"],label: "页面5"} 
            }
        ]
    },
    {
        path: "*",
        name: "Not",
        component: () => import('@/pages/not.vue')
    }
]