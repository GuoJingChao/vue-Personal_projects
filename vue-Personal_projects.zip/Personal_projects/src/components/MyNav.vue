<template>
    <div class="nav">
        <label class="label clearfix" v-for="(item, index) in this.list" :key="index">
            <el-submenu v-if="item.children && item.children.length > 0" :index="item.path">
                <template slot="title">{{ item.meta.label }}</template>
                <my-nav :list="item.children" />
            </el-submenu>
            <el-menu-item v-else :index="item.path">{{ item.meta.label }}</el-menu-item>
        </label>
    </div>
</template>

<script>
export default {
    data() {
        return {}
    },
    props: ["list"],
}
</script>

<style scoped>
</style>