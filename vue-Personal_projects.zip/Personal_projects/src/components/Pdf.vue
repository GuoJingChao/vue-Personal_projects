<template>
  <div id="showPdf">
    <el-scrollbar ref="elscrollbar" style="width: 100%; height: 400px;overflow-y: hidden; border-top: 2px solid #333333;">
      <div class="position page">
        <span class="span_1" @click="pageUp">上一页</span>
        <span>页码：{{`${pageNo}/${totals.length}`}}</span>
        <span class="span_2" @click="pageDown">下一页</span>
      </div>
      <div class="position info">
        <span class="span_1">上传者：{{pdfInfo.updateBy}}</span>
        <span>上传时间：{{pdfInfo.updateOn}}</span>
        <span class="span_2">附件编号：{{pdfInfo.workNo}}</span>
      </div>
      <div class="main_content" id="mainContent" ref="mainContent">
        <div v-for="item in totals" :id="`page-${item}`" :key="item" class="pdf-box">
          <canvas :id="'canvas-pdf-' + item" class="canvas-pdf"></canvas>
        </div>
      </div>
    </el-scrollbar>
  </div>
</template>

<script>
import PDFJS from 'pdfjs-dist'
import axios from 'axios'
import { TextLayerBuilder } from 'pdfjs-dist/web/pdf_viewer'
import 'pdfjs-dist/web/pdf_viewer.css'
export default {
  name: 'showPdf',
  props: ['pdfUrl', 'pdfInfo'],
  data () {
    return {
      scale: 1.2,
      totals: [],
      pageNo: 1,
      viewHeight: 0,
      scrollbar: ''
    }
  },
  mounted () {
    this.scrollbar = this.$refs['elscrollbar'].$refs['wrap']
    this.scrollbar.addEventListener('scroll', this.scrollfun, false)
    this.getMainContentWidth()
    this.getPdfFun()
  },
  methods: {
    // 当PDF地址跨域时，后台以流的形式传输PDF
    getPdfFun () {
      axios({
        method: 'get',
        url: this.pdfUrl,
        data: {},
        responseType: 'blob'
      }).then(res => {
        let url = window.URL.createObjectURL(new Blob([res.data]))
        this.renderPdf(url)
      })
    },
    getMainContentWidth () {
      let div = this.$refs.mainContent
      let width = window.getComputedStyle(div).width
      this.contentWidth = parseInt(width)
    },
    renderPdf (pdfUrl) {
      PDFJS.workerSrc = require('pdfjs-dist/build/pdf.worker.min')
      PDFJS.getDocument(pdfUrl).then(pdf => {
        let totalPage = pdf.numPages
        let idName = 'canvas-pdf-'
        this.createCanvas(totalPage, idName)
        for (let i = 1; i <= totalPage; i++) {
          pdf.getPage(i).then((page) => {
            let pageDiv = document.getElementById(`page-${i}`)
            // let viewport = page.getViewport(scale)
            let viewportFirst = page.getViewport(1)
           // 计算 scale值，this.contentWidth 为 ref = mainContent 的元素的宽度
            let scale = this.contentWidth / viewportFirst.width
            let viewport = page.getViewport(scale)
            let canvas = document.getElementById(idName + i)
            let context = canvas.getContext('2d')
            canvas.height = viewport.height
            canvas.width = viewport.width
            this.viewHeight = viewport.height
            let renderContext = {
              canvasContext: context,
              viewport
            }
            page.render(renderContext).then(() => {
              return page.getTextContent()
            }).then((textContent) => {
              // 创建文本图层div
              const textLayerDiv = document.createElement('div')
              textLayerDiv.setAttribute('class', 'textLayer')
              // 将文本图层div添加至每页pdf的div中
              pageDiv.appendChild(textLayerDiv)
              // 创建新的TextLayerBuilder实例
              let textLayer = new TextLayerBuilder({
                textLayerDiv: textLayerDiv,
                pageIndex: page.pageIndex,
                viewport: viewport
              })
              textLayer.setTextContent(textContent)
              textLayer.render()
              if (i == totalPage) {
                this.$store.commit("set_loading", false)
              }
            })
          })
        }
      })
    },
    createCanvas (totalPages) {
      for (let i = 1; i <= totalPages; i++) {
        this.totals.push(i)
      }
    },
    /**
     * 分页
     */
    scrollfun (e) {
      let scrollTop = e.target.scrollTop
      if (scrollTop === 0) {
        this.pageNo = 1
      } else {
        let totalPages = this.totals.length
        this.pageNo = Math.ceil(scrollTop / (this.scrollbar.scrollHeight / totalPages) + 0.1)
      }
    },
    /**
     * 上一页
     */
    pageUp () {
      let totalPages = this.totals.length
      if (this.pageNo > 0) {
          this.scrollbar.scrollTop = (this.pageNo - 2) * (this.scrollbar.scrollHeight / totalPages)
      }
    },
    /**
     * 下一页
     */
    pageDown () {
      let totalPages = this.totals.length
      window.console.log(totalPages)
      if (this.pageNo < totalPages) {
        this.scrollbar.scrollTop = this.pageNo * (this.scrollbar.scrollHeight / totalPages)
      }
    }
  }
}
</script>

<style lang="scss">
  #showPdf {
    width: 600px;
    position: absolute;
    left: 10%;  
    top: 5%;
    background-color: #409EFF;
    .position {
      position: absolute;
      left: 0;
      right: 0;
      background: rgba(0, 0, 0, 0.2);
      z-index: 100;
      padding: 0 15px;
      line-height: 25px;
      color: #fff;
      .span_1 {
        float: left;
      }
      .span_2 {
        float: right;
      }
    }
    .page {
      bottom: 0;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
      .span_1 {
        cursor: pointer;
      }
      .span_2 {
        cursor: pointer;
      }
    }
    .info {
      top: 0;
    }
    .pdf-box {
      position: relative;
      text-align: left;
      display: inline-block;
    }
  }
</style>