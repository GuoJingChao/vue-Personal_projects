<template>
    <div class="footer" :style="`background-color:${this.color};`">
        {{ msg }}
    </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
    name: "Footer",
    data() {
        return {
            msg: "Footer"
        }
    },
    computed: {
        ...mapState(["color"])
    }
};
</script>

<style scoped>
.footer {
    width: 100%;
    height: 65px;
    background-color: #b3c0d1;
    text-align: center;
    line-height: 65px;
    font-size: 22px;
    font-weight: bold;
}
</style>