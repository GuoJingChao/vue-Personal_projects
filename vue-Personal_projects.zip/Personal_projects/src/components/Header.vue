<template>
    <div class="header" :style="`background-color:${this.color};`">
        {{ msg }}
    </div>    
</template>

<script>
import { mapState } from 'vuex'
export default {
    name: "Header",
    data() {
        return {
            msg: "Header"
        }
    },
    mounted() {},
    computed: {
        ...mapState(["color"])
    }
}
</script>

<style scoped>
    .header {
        width: 100%;
        height: 65px;
        background-color: #b3c0d1;
        text-align: center;
        line-height: 65px;
        font-size: 22px;
        font-weight: bold;
    }
</style>