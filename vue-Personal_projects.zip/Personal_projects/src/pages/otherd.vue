<template>
    <div class="other">
        <h1>otherd</h1>
    </div>
</template>

<script>
export default {
    name: "OtherD",
    data() {
        return {}
    }
}
</script>

<style scoped>

</style>