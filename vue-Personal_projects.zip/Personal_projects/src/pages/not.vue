<template>
    <div class="not">
        <h1>404</h1>
    </div>
</template>

<script>
export default {
    name: "Not"
}
</script>

<style scoped>

</style>