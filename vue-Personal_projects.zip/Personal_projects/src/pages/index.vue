<template>
    <div class="index">
        <div class="clearfix indexbox">
            <el-menu
                :default-active="activeIndex"
                class="el-menu-demo fl"
                @select="handleSelect"
                background-color="#545c64"
                text-color="#fff"
                active-text-color="#ffd04b">
                <my-nav :list="this.newrouter[0].children" />
            </el-menu>
            <div class="fl boxfl">
                <my-Header />
                <el-breadcrumb class="bread" separator="/">
                    <el-breadcrumb-item v-for="(item, index) in this.routearr" :key="index" 
                        :to="item.path ? item.path : '/'" 
                    >{{ item.meta.label }}</el-breadcrumb-item>
                </el-breadcrumb>
                <router-view></router-view>
                <my-Footer />
            </div>
        </div>
    </div>
</template>

<script>
import { mapState } from 'vuex';

export default {
    name: "IndexHome",
    data() {
        return {
            activeIndex: "",
            activePath: ""
        }
    },
    watch: {
		'$route': function (newUrl) { // 试试监听路由变化，分配面包屑导航内容
            let path = newUrl.path.split("/")
            this.activeIndex = path[path.length - 1]
		}
	},
    computed: {
        ...mapState(["newrouter", "routearr"])
    },
    mounted() {
        this.handleBread()
    },
    methods: {
        handleSelect(key, keyPath) { // 导航自定义跳转
            let path = "";
            keyPath.map((item) => {
                path += "/" + item
            })
            this.$router.push(path)
        },
        handleBread() { //初始化面包屑导航
            let path = this.$route.path.split("/")
            this.activeIndex = path[path.length - 1]
        }
    }
}
</script>

<style scoped>
.indexbox {
    display: flex;
}
.el-menu-demo {
    width: 200px;
}
.boxfl {
    width: 100%;
    flex:1;
}
.bread {
    padding-top: 20px;
    padding-left: 20px;
}
</style>