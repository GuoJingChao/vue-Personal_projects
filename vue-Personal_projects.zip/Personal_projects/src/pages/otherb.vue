<template>
    <div class="other">
        <h1>otherb</h1>
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name: "OtherB",
    data() {
        return {}
    }
}
</script>

<style scoped>

</style>