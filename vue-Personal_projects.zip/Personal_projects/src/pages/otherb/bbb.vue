<template>
    <div>bbbbbb</div>
</template>

<script>
export default {
    name: "BBB",
}
</script>

<style scoped>

</style>