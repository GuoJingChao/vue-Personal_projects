<template>
    <div>bbbbbb2</div>
</template>

<script>
export default {
    name: "BBB2",
}
</script>

<style scoped>

</style>