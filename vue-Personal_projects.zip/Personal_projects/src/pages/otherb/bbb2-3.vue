<template>
    <div>bbbbbb2-3</div>
</template>

<script>
export default {
    name: "BBB2-3",
}
</script>

<style scoped>

</style>