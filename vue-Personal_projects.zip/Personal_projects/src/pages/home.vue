<template>
	<div class="home">
		<div class="block">
			<el-color-picker v-model="color1" show-alpha></el-color-picker>
		</div>
		<h1>您好，{{ username }}</h1>
		<div class="code clearfix">
			<el-input v-model="input" placeholder="只能输入整数"></el-input>
			<br /><br />
			<el-input v-model="id" placeholder="请输入身份证号码"></el-input>
			<el-button type="primary" @click="submitId">验证</el-button>
		</div>
		<el-button type="primary" @click="gopage(1)">去参数页面(路由定义传参)</el-button>
		<el-button type="success" @click="gopage(2)">去参数页面(url无参数显示传参)</el-button>
		<el-button type="warning" @click="gopage(3)">去参数页面(url?拼接传参)</el-button>
		<h1><el-button type="danger" @click="logout">退出</el-button></h1>
	</div>
</template>

<script>
import { mapState } from "vuex"

export default {
	name: 'Home',
	data() {
		return {
			input: '',
			id: '',
			color1: '',
		}
	},
	mounted() {
		this.color1 = this.color
	},
	methods: {
		logout() {
			this.$confirm('您真的要退出么？', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				this.$message({
					type: 'success',
					message: `${this.username}，我等您回来`
				});
				localStorage.removeItem("username")
				localStorage.removeItem("role")
				setTimeout(() => {
					location.reload();
				}, 700);
			}).catch(() => {
				this.$message({
					type: 'info',
					message: '暂时取消退出登录'
				});
			});
		},
		submitId() {
			if (this.id === "") {
				this.$message.error("身份证号码不能为空！")
			}else {
				let is_id = this.$textCode(this.id)
				if (!is_id) {
					this.$message.error("请输入正确身份证信息")
				}else {
					this.$message({
						type: 'success',
						message: `身份证正确！`
					});
				}
			}
		},
		gopage(id) {
			if (id == 1) {
				this.$router.push({"path": `/all/${this.username}`})
			}else if (id == 2) {
				this.$router.push({name:'All2', params: { name: this.username }})
			}else {
				this.$router.push(`/all3?name=${this.username}`)
			}
		}
	},
	computed: {
		...mapState(["username", "color"])
	},
	watch: {
		color1(newcolor) {
			this.$store.commit("set_color", newcolor)
			localStorage.setItem("color", newcolor)
		},
		input(newval) {
			this.input = newval.replace(/[^0-9]+/g,'')
		}
	}
}
</script>

<style scoped>
.code {
	margin-bottom: 30px;
}

.code .el-input {
	width: 400px;
	display: inline-block
}

.code .el-button {
	display: inline-block
}
</style>
