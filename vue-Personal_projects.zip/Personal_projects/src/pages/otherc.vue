<template>
    <div class="other">
        <h1>otherc</h1>
    </div>
</template>

<script>
export default {
    name: "OtherC",
    data() {
        return {}
    }
}
</script>

<style scoped>

</style>