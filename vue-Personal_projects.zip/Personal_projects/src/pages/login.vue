<template>
    <div class="login">
        <h1>Guo Jing Chao</h1>
        <el-form :label-position="labelPosition" :model="ruleForm" :rules="rules" ref="ruleForm">
            <el-form-item label="用户名" prop="username">
                <el-input v-model="ruleForm.username"></el-input>
            </el-form-item>
            <el-form-item label="密码" prop="password">
                <el-input type="password" v-model="ruleForm.password"></el-input>
            </el-form-item>
            <el-checkbox v-model="checked">记住密码</el-checkbox>
            <br /><br />
            <el-form-item>
                <el-button type="primary" @click="submitForm('ruleForm')">登陆</el-button>
                <el-button @click="resetForm('ruleForm')">重置</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
export default {
    name: "Login",
    data() {
        return {
            checked: true,
            isLogin: false,
            labelPosition: 'right',
            ruleForm: {
                username: localStorage.getItem("name"),
                password: localStorage.getItem("password")
            },
            rules: {
                username: [
                    { required: true, message: '请输入用户名', trigger: 'blur' },
                ],
                password: [
                    { required: true, message: '请输入密码', trigger: 'blur' },
                    { min: 3, max: 12, message: '长度在 3 到 12 个字符', trigger: 'blur' }
                ]
            }
        }
    },
    mounted() {
        if (localStorage.getItem("checked") == 'true') {
            this.checked = true
        }else if (localStorage.getItem("checked") == 'false') {
            this.checked = false
        }
    },
    methods: {
        submitForm(formName) {
            this.$refs[formName].validate((valid) => {
                if (valid){
                    var that = this;
                    this.$axios.get("/mock/login.json").then((response) => {
                        let res = response.data
                        res.data.map((value) => {
                            if (value.username === that.ruleForm.username) {
                                if (value.password === that.ruleForm.password) {
                                    // 登陆成功
                                    that.$message({
                                        message: `欢迎回来，${value.username}`,
                                        type: 'success'
                                    })
                                    // 通过 vuex 储存全局变量 需要保存的有，用户名 权限标识
                                    that.$store.commit("set_username", value.username) // 用户名
                                    that.$store.commit("set_role", value.role) // 权限标识
                                    // 通过储存本地存储 把用户名和权限标识保存袄浏览器缓存，防止用户刷新页面
                                    localStorage.setItem("username", value.username)
                                    localStorage.setItem("role", value.role)
                                    // 记住密码
                                    localStorage.setItem("checked", this.checked)
                                    if (this.checked) {
                                        localStorage.setItem("name", value.username)
                                        localStorage.setItem("password", this.ruleForm.password)
                                    }else {
                                        if (localStorage.getItem("password")) {
                                            localStorage.removeItem("name")
                                            localStorage.removeItem("password")
                                        }
                                    }
                                    that.isLogin = true
                                }
                            }
                        })
                        if (!that.isLogin) {
                            that.$message.error("很抱歉，账号或密码错误！")
                        }else {
                            that.$router.push({path: "/"}).catch(() => {})    
                        }
                    }).catch((err) => {
                        window.console.log(err)
                    });
                }else {
                    window.console.log('error submit!!');
                    return false;
                }
            })
        },
        resetForm(formName) {
            this.$refs[formName].resetFields();
        }
    }
}
</script>

<style scoped>
    .login {
        width: 600px;
        margin: 100px auto 0;
        border: 1px solid hsl(202, 90%, 69%);
        border-radius: 5px;
    }
    .login form {
        padding: 20px;
    }
    h1 {
        font-family: "Ink Free";
        font-size: 40px;
        margin-bottom: 10px;
    }
</style>