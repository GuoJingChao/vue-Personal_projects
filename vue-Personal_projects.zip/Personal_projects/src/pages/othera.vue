<template>
    <div class="other">
        <h1>othera</h1>
        <el-button class="button" type="primary" @click="getPDF">点击查看彬跃计划pdf</el-button>
        <vuePdf v-if="ispdf" :pdfUrl="url" :pdfInfo="info"></vuePdf>
    </div>
</template>

<script>
import vuePdf from "../components/Pdf.vue"

export default {
    name: "OtherA",
    data() {
        return {
            ispdf: false,
            url: "/binyue.pdf",
            info: {
                updateBy: "GuoJingChao",
                workNo: "888",
                updateOn: "2019年11月7日15:14:10"
            }
        }
    },
    methods: {
        getPDF() {
            this.ispdf = !this.ispdf
            this.$store.commit("set_loading", this.ispdf)
        }
    },
    components: {
        vuePdf
    },
}
</script>

<style scoped>
    .other {
        padding-bottom: 50px;
    }
</style>