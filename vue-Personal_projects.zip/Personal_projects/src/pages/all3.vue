<template>
    <div>
        <h1>all</h1>
        <h1>{{ username }}</h1>
        <el-button type="primary" @click="goback">返回</el-button>
    </div>
</template>

<script>
export default {
    name: "All3",
    data() {
        return {
            username: ""
        }
    },
    mounted() {
        this.username = this.$route.query.name
    },
    methods: {
        goback() {
            this.$router.push("/home");
        }
    }
}
</script>

<style scoped>

</style>