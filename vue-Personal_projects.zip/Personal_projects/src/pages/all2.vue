<template>
    <div>
        <h1>all</h1>
        <h1>{{$route.params.name}}</h1>
        <h1>刷新页面会参数丢失，建议保存本地存储</h1>
        <el-button type="primary" @click="goback">返回</el-button>
    </div>
</template>

<script>
export default {
    name: "All2",
    data() {
        return {}
    },
    mounted() {},
    methods: {
        goback() {
            this.$router.push("/home");
        }
    }
}
</script>

<style scoped>

</style>