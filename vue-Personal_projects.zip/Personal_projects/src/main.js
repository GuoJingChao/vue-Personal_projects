import Vue from 'vue'
import App from './App.vue'

import router from "./router/index.js"
import store from "./store/index.js"
import axios from "axios"

import MyHeader from "@/components/Header"
import MyFooter from "@/components/Footer"
import MyNav from "@/components/MyNav.vue"

// element ui 组件
import { Button, Form, FormItem, Input, Message, MessageBox, Menu, MenuItem, Submenu, Breadcrumb, BreadcrumbItem, ColorPicker, Checkbox, Scrollbar, Loading } from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

// element ui 组件挂载
Vue.use(Button)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Input)
Vue.use(Menu)
Vue.use(MenuItem)
Vue.use(Submenu)
Vue.use(Breadcrumb)
Vue.use(BreadcrumbItem)
Vue.use(ColorPicker)
Vue.use(Checkbox)
Vue.use(Scrollbar)
Vue.use(Loading)
Vue.prototype.$confirm = MessageBox.confirm
Vue.prototype.$message = Message

// axios 挂载
Vue.prototype.$axios = axios

// 
Vue.config.productionTip = false

// 全局方法 验证身份证
Vue.prototype.$textCode = (idCard) => {/*加权因子验证身份证*/
    let regIdCard = /^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/;
    //如果通过该验证，说明身份证格式正确，但准确性还需计算
    if (regIdCard.test(idCard)) {
        if (idCard.length == 18) {
            var idCardWi = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2); //将前17位加权因子保存在数组里
            var idCardY = new Array(1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2); //这是除以11后，可能产生的11位余数、验证码，也保存成数组
            var idCardWiSum = 0; //用来保存前17位各自乖以加权因子后的总和
            for (var i = 0; i < 17; i++) {
                idCardWiSum += idCard.substring(i, i + 1) * idCardWi[i];
            }
            var idCardMod = idCardWiSum % 11;//计算出校验码所在数组的位置
            var idCardLast = idCard.substring(17);//得到最后一位身份证号码
            //如果等于2，则说明校验码是10，身份证号码最后一位应该是X
            if (idCardMod == 2) {
                if (idCardLast == "X" || idCardLast == "x") {
                    return true;
                } else {
                    return false;
                }
            } else {
                //用计算出的验证码与最后一位身份证号码匹配，如果一致，说明通过，否则是无效的身份证号码
                if (idCardLast == idCardY[idCardMod]) {
                    return true;
                } else {
                    return false;
                }
            }
        }
    } else {
        return false;
    }
}

// 全局组件挂载
Vue.component("my-Header", MyHeader)
Vue.component("my-Footer", MyFooter)
Vue.component("my-nav", MyNav)

// 需要权限判断的路由引入
import { powerRouter } from "@/router/index.js"

// 路由导航守卫，权限判断的重点
router.beforeEach((to, from, next) => {
	if (to.path === "/login") { // 用户去登录页面就去
		next()
	}else {
		// 不是登陆就做判断
		if (store.getters.role) { // 查看vuex中是否保存了用户权限
			if (store.getters.newrouter.length !== 0) { // 查看vuex中新路由 是否已经匹配
				if (to.matched && to.matched.length > 0) { // 面包屑导航逻辑
					store.commit("set_routearr", [])
					let route = []
					to.matched.map((item, index) => {
						if (route.length > 0) {
							if (route[index - 1]) {
								if (item.meta.label !== route[index - 1].meta.label) {
									route.push(item)					
								}
							}
						}else {
							route.push(item)
						}
					})
					store.commit("set_routearr", route)
				}
				next() // 符合条件后跳转
			}else { // 路由权限逻辑
				let newrouter = []
				if (store.getters.role === "A") {
					newrouter = powerRouter
				}else {
					let newchildren = powerRouter[0].children.filter((route) => {
						return $each(route) // 动态分配路由
					})
					newrouter = powerRouter
					newrouter[0].children = newchildren
				}
				store.commit("set_newrouter", newrouter) // 新路由储存到 vuex
				router.addRoutes(newrouter)
				next({...to})
			}
		}else { // 不满足条件 拉回登陆页面
			next('/login')
		}
	}
})

// 自定义递归分配路由方法
function $each(route) {
	if (route.children) {
		let newchildren = route.children.filter((route) => {
			return $each(route)
		})
		route.children = newchildren
	}
	if (route.meta) {
		if (route.meta.role) {
			if (route.meta.role.indexOf(store.getters.role) >= 0 ) {
				return true
			}
		}else {
			return true
		}
	}else {
		return true
	}
}

new Vue({
	render: h => h(App),
	router,
	store
}).$mount('#app')
